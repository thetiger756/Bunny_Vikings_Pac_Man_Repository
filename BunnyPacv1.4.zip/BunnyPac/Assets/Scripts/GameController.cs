﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public GameObject[] powerup;
    public Vector3 powerValues;
    public float startWait;

    public Text ScoreText;
    public Text restartText;
    public Text gameOverText;
    public Text winText;

    public bool gameOver;
    private bool restart;
    private int score;

    public static GameController Instance;

    public AudioClip song1;
    public AudioClip song2;
    public AudioClip song3;

    private AudioSource audioSource;
    private bool paused1;
    private bool paused2;
    private bool paused3;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        gameOver = false;
        //restart = false;
       // restartText.text = "";
        gameOverText.text = "";
        winText.text = "";
        score = 0;
        UpdateScore();

        audioSource = GetComponent<AudioSource>();
        paused1 = true;
        paused2 = true;
        paused3 = true;
    }

    private void Update()
    {
        if (restart)
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                SceneManager.LoadScene("Main");
            }
        }
        if (paused1 && paused3 && paused2)
        {
            audioSource.clip = song1;
            audioSource.Play(0);
            paused1 = false;
        }
    }

    public void AddScore(int newScoreValue)
    {
        score += newScoreValue;
        UpdateScore();
    }

    void UpdateScore()
    {
        ScoreText.text = "Points: " + score;
        if (score >= 200)
        {
            winText.text = "You Win!\n Game Created\n by\n Corey Gillian";
            gameOver = true;
            restart = true;
            if (paused2 && paused3)
            {
                paused1 = true;
                audioSource.clip = song2;
                audioSource.Play(0);
                paused2 = false;
            }
        }
    }

    public void GameOver()
    {
        gameOverText.text = "Game Over!\n Game Created\n by\n Corey Gillian";
        gameOver = true;
        if (paused2 && paused3)
        {
            paused1 = true;
            audioSource.clip = song3;
            audioSource.Play(0);
            paused3 = false;
        }
    }
}
