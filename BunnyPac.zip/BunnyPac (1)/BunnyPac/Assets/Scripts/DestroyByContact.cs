﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyByContact : MonoBehaviour
{
    public bool eatingPellets;

    public bool powerPelletActive;

    private void Start()
    {
        eatingPellets = false;
    }

    private void Update()
    {
        Debug.Log(powerPelletActive);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy")
        {
            if (powerPelletActive == false)
            {
            GameObject.Find("GameControllerHolder").GetComponent<GameController>().justDied = true;

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().lives -= 1;

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().SetLiveText();

            gameObject.SetActive(false);
            }
            
            else if (powerPelletActive == true)
            {
                GameObject.Find("GameControllerHolder").GetComponent<GameController>().justDied = false;

                GameObject.FindGameObjectWithTag("Body").SetActive(false);

                gameObject.SetActive(false);
            }
        }

        if (other.tag == "Pellet")
        {
            eatingPellets = true;

            other.gameObject.SetActive(false);

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().score += 10;

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().UpdateScore();
;
        }

        if (other.tag == "PowerPellet")
        {
            other.gameObject.SetActive(false);

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().score += 50;

            StartCoroutine(PoweredUp());
        }
    }

    IEnumerator PoweredUp()
    {
        powerPelletActive = true;

        //yield on a new YieldInstruction that waits for 10 seconds.
        yield return new WaitForSeconds(10);

        powerPelletActive = false;
    }
}
