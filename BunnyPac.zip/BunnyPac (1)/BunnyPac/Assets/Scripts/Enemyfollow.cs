﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Enemyfollow : MonoBehaviour
{
    public float speed;
    private Transform target;
    private GameController gameController;

   private Vector3 previousTransform;

    public NavMeshAgent agent;

    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

        ////RotateEnemy();
        
        //rotates enemy
        if (target.transform.position != this.transform.position)
        {
            
            Vector3.MoveTowards(transform.position, target.transform.position, speed);
            transform.LookAt(target.transform);
            agent.SetDestination(target.transform.position);
        }
        

        previousTransform = transform.position;

        Debug.Log(previousTransform);
    }

    //void RotateEnemy()
    //{
        ////down
        //if (previousTransform.z > transform.position.z)
        //{
        //    transform.rotation = Quaternion.Euler(0, 180, 0);
        //}
        ////up
        //else if (previousTransform.z<transform.position.z)
        //{
        //    transform.rotation = Quaternion.Euler(0, 0, 0);
        //}
        ////left
        //else if (previousTransform.x > transform.position.x)
        //{
        //    transform.rotation = Quaternion.Euler(0, 270, 0);
        //}
        ////right
        //else
        //{
        //    transform.rotation = Quaternion.Euler(0, 90, 0);
        //}
    //}
}

