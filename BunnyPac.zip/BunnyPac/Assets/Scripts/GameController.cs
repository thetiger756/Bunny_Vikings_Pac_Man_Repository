﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameController : MonoBehaviour
{
    public static GameController Instance;

    public Text scoreText;
    public Text restartText;
    public Text gameOverText;
    public Text winText;
    public Text livesText;

    public bool gameOver;
    private bool restart;
    public bool justDied;

    public int score;
    public int lives;

    AudioSource audioSource;
    public AudioClip startTune;
    public AudioClip deathTune;

    public GameObject gameoverBG;
    public GameObject winGraphic;
    public GameObject loseGraphic;


    //respawn points for enemies and players after death and not game over
    public EnemyFollow eNemyStart;
    private Vector3 enemyStartpoint;
    public EnemyFollow eNemyStart1;
    private Vector3 enemyStartpoint1;
    public EnemyFollow eNemyStart2;
    private Vector3 enemyStartpoint2;
    public EnemyFollow eNemyStart3;
    private Vector3 enemyStartpoint3;

    public PlayerController thePlayer;
    private Vector3 PlayerStartpoint;

    //next level spawn point
    //public GameObject oRigin;
    //private Vector3 NewLvlStart;

    //Play the music
    bool m_Play;
    //Detect when you use the toggle, ensures music isn’t played multiple times
    bool m_ToggleChange;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        

        //enemy respawn points
        enemyStartpoint = eNemyStart.transform.position;
        enemyStartpoint1 = eNemyStart1.transform.position;
        enemyStartpoint2 = eNemyStart2.transform.position;
        enemyStartpoint3 = eNemyStart3.transform.position;

        PlayerStartpoint = thePlayer.transform.position;


        gameOver = false;
        restart = false;
        justDied = false;

        gameoverBG.SetActive(false);
        winGraphic.SetActive(false);
        loseGraphic.SetActive(false);

        //score = 0;
        lives = 3;

        scoreText.text = "";
        restartText.text = "";
        gameOverText.text = "";
        winText.text = "";
        livesText.text = "";

        SetLiveText();
        UpdateScore();

        audioSource = gameObject.GetComponent<AudioSource>();

        audioSource.clip = startTune;
        m_Play = true;

        PlayStartTune();
    }

    void Update()
    {
        if (restart)
        {
            if (Input.GetKeyDown(KeyCode.Q))
            {
                SceneManager.LoadScene("Menu");
            }
        }

        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }

        AudioManager();
    }

    
    public void AddScore(int newScoreValue)
    {
        score += newScoreValue;
        UpdateScore();
    }

    public void UpdateScore()
    {
        //checking the scene
        Scene currentScene = SceneManager.GetActiveScene();
        string sceneName = currentScene.name;

        scoreText.text = "Points: " + score;
        
        if (sceneName == "Level1")
        {
            if(score >= 1140)
            {
                SceneManager.LoadScene("Level2");
            }
        }

        else if (score >= 2280)
        {

            winText.text = "You Win!";
            gameoverBG.SetActive(true);
            winGraphic.SetActive(true);
            gameOver = true;
            if (gameOver)
            {
                restartText.text = "Press 'Q' to go to the Menu";
                restart = true;
            }
            GameObject.FindGameObjectWithTag("Enemy").SetActive(false);

        }
    }

    public void GameOver()
    {
        gameOverText.text = "Game Over!";
        gameOver = true;
        GameObject.FindGameObjectWithTag("Enemy").SetActive(false);
        gameoverBG.SetActive(true);
        loseGraphic.SetActive(true);
        if (gameOver)
        {
            restartText.text = "Press 'Q' to go to the Menu";
            restart = true;
        }
    }

    public void SetLiveText()
    {
        livesText.text = "Lives: " + lives.ToString();

        if (lives == 0)
        {
            GameOver();
        }

        else if (lives >= 1)
        {
            Respawn();
        }
    }

    public void Respawn()
    {
        StartCoroutine("RestartGameCo");
    }

    public IEnumerator RestartGameCo()
    {
        eNemyStart.gameObject.SetActive(false);
        eNemyStart1.gameObject.SetActive(false);
        eNemyStart2.gameObject.SetActive(false);
        eNemyStart3.gameObject.SetActive(false);

        thePlayer.gameObject.SetActive(false);

        yield return new WaitForSeconds(0.5f);

        eNemyStart.transform.position = enemyStartpoint;
        eNemyStart1.transform.position = enemyStartpoint1;
        eNemyStart2.transform.position = enemyStartpoint2;
        eNemyStart3.transform.position = enemyStartpoint3;

        thePlayer.transform.position = PlayerStartpoint;
        thePlayer.gameObject.SetActive(true);

        yield return new WaitForSeconds(0.3f);
        eNemyStart.gameObject.SetActive(true);
        yield return new WaitForSeconds(1f);
        eNemyStart1.gameObject.SetActive(true);
        yield return new WaitForSeconds(2f);
        eNemyStart2.gameObject.SetActive(true);
        yield return new WaitForSeconds(3f);
        eNemyStart3.gameObject.SetActive(true);
    }

    void AudioManager()
    {
        //Check to see if you just set the toggle to positive
        if (m_Play == true && m_ToggleChange == true)
        {
            //Play the audio you attach to the AudioSource component
            audioSource.Play();
            //Ensure audio doesn’t play more than once
            m_ToggleChange = false;
        }
        //Check if you just set the toggle to false
        if (m_Play == false && m_ToggleChange == true)
        {
            //Stop the audio
            audioSource.Stop();
            //Ensure audio doesn’t play more than once
            m_ToggleChange = false;
        }

        if (GameObject.Find("GameControllerHolder").GetComponent<GameController>().justDied == true)
        {
            PlayDeathTune();

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().justDied = false;
        }
    }

    void PlayStartTune()
    {
        audioSource.clip = startTune;

        m_ToggleChange = true;
    }

    void PlayDeathTune()
    {
        audioSource.clip = deathTune;

        m_ToggleChange = true;
    }
}
