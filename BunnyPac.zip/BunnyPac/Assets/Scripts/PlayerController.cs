﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class PlayerController : MonoBehaviour
{
    //By Seth Ruiz
    //I am still learning how to code, so this will be sloppy.
    //But at least there are comments.

    //Bring in the controller component
    public CharacterController controller;

    
    //How fast do we want to go
    private float playerSpeed = 3;

    //To eliminate acceleration
    //We need to keep track of what the player was inputting last frame
    private float xLog = 0;
    private float zLog = 0;
    //And interpret the correct int to round to based on that and their current input
    private float xRounded = 0;
    private float zRounded = 0;

    public GameObject model;

    AudioSource audioSource;

    public AudioClip eatingPelletsSound;

    //Play the music
    bool m_Play;
    //Detect when you use the toggle, ensures music isn’t played multiple times
    bool m_ToggleChange;

    void Start()
    {
        audioSource = gameObject.GetComponent<AudioSource>();

        m_Play = true;
    }

    void Update()
    {
        PlayerEngine();

        AudioManagerWakka();
    }

    void AudioManagerWakka()
    {
        //Check to see if you just set the toggle to positive
        if (m_Play == true && m_ToggleChange == true)
        {
            //Play the audio you attach to the AudioSource component
            audioSource.Play();
            //Ensure audio doesn’t play more than once
            m_ToggleChange = false;
        }
        //Check if you just set the toggle to false
        if (m_Play == false && m_ToggleChange == true)
        {
            //Stop the audio
            audioSource.Stop();
            //Ensure audio doesn’t play more than once
            m_ToggleChange = false;
        }

        if (GameObject.Find("Player").GetComponent<DestroyByContact>().eatingPellets == true)
        {
            PlayPelletSounds();

            GameObject.Find("Player").GetComponent<DestroyByContact>().eatingPellets = false;
        }
    }

    void PlayPelletSounds()
    {
        audioSource.clip = eatingPelletsSound;

        m_ToggleChange = true;
    }

    void PlayerEngine()
    {
        //Look for WASD and Arrow Key Input. 
        //x and z will always be some decimal between -1 and 1
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        //To get rid of acceleration we want to round to an int.
        //We have to use multiple rules so that we can interpret
        //player intent and keep the game feeling responsive

        //When moving right and speeding up
        if (x > 0 && x > xLog)
        {
            //Round up
            xRounded = Mathf.CeilToInt(x);
        }
        //Make the player stop immediately when they let go
        else if (x > 0 && x < xLog)
        {
            xRounded = 0;
        }

        //Now for the left
        else if (x < 0 && x < xLog)
        {
            xRounded = Mathf.FloorToInt(x);
        }
        else if (x < 0 && x > xLog)
        {
            xRounded = 0;
        }

        //And this keeps edge cases snappy
        else if (x == 0)
        {
            xRounded = 0;
        }

        //repeat above for vertical movement
        if (z > 0 && z > zLog)
        {
            zRounded = Mathf.CeilToInt(z);
        }
        else if (z > 0 && z < zLog)
        {
            zRounded = 0;
        }
        else if (z < 0 && z < zLog)
        {
            zRounded = Mathf.FloorToInt(z);
        }
        else if (z < 0 && z > zLog)
        {
            zRounded = 0;
        }
        else if (z == 0)
        {
            zRounded = 0;
        }

        //Limit movement to one axis at a time
        //Unfortunately this creates a situation where vertical input takes
        //priority over horizontal movement. Maybe this can be fixed in the future.
        if (zRounded != 0)
        {
            xRounded = 0;
        }

        //Create a vector3 (0, 0, 0) called "move"
        //transform.right is the first part of the vector3; it is modified by the player's input
        //transform.forward is the last part of the vector3; it is also modified by the player's input
        Vector3 move = transform.right * xRounded + transform.forward * zRounded;

        //Player Model Rotation
        if (zRounded > 0)
        {
            model.transform.rotation = Quaternion.Euler(0, -90, 0);
        }
        if (zRounded < 0)
        {
            model.transform.rotation = Quaternion.Euler(0, 90, 0);
        }
        if (xRounded > 0)
        {
            model.transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        if (xRounded < 0)
        {
            model.transform.rotation = Quaternion.Euler(0, -180, 0);
        }

        //Tell the controller to move the player based on their input modified by our set speed
        controller.Move(move * playerSpeed * Time.deltaTime);

        //write down what x and z were for this frame
        xLog = x;
        zLog = z;
    }
}