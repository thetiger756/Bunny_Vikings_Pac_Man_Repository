﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyByContact : MonoBehaviour
{
    public bool eatingPellets;

    public bool powerPelletActive;

    public bool eYesonly;

    private void Start()
    {
        eatingPellets = false;
        eYesonly = GameObject.FindGameObjectWithTag("Body");
    }

    private void Update()
    {
        Debug.Log(powerPelletActive);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy")
        {
            if (powerPelletActive == false)
            {
            GameObject.Find("GameControllerHolder").GetComponent<GameController>().justDied = true;

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().lives -= 1;

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().SetLiveText();

            gameObject.SetActive(false);
            }
            
            else if (powerPelletActive == true)
            {
                GameObject.Find("GameControllerHolder").GetComponent<GameController>().justDied = false;

                StartCoroutine(EnemyBody());
            }
        }

        if (other.tag == "Pellet")
        {
            eatingPellets = true;

            other.gameObject.SetActive(false);

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().score += 1;

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().UpdateScore();
;
        }

        if (other.tag == "PowerPellet")
        {
            other.gameObject.SetActive(false);

            GameObject.Find("GameControllerHolder").GetComponent<GameController>().score += 50;

            StartCoroutine(PoweredUp());
        }
    }

    IEnumerator PoweredUp()
    {
        powerPelletActive = true;

        //yield on a new YieldInstruction that waits for 10 seconds.
        yield return new WaitForSeconds(10);

        powerPelletActive = false;
    }

    IEnumerator EnemyBody()
    {
        eYesonly = false;

        yield return new WaitForSeconds(10);

        eYesonly = true;
    }
}
