﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{
    public Text pressText;

    void Start()
    {
        pressText.text = "Press Enter to Start";
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            SceneManager.LoadScene("Level1");
        }

        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }
}
