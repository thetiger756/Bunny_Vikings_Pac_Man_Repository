﻿using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class EnemyFollow : MonoBehaviour
{

    //to store the player's location
    Vector3 target;
    Vector3 oRigin;

    //reference to the agent component
    NavMeshAgent agent;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        oRigin = GameObject.FindGameObjectWithTag("Origin").transform.position;
    }

    void FixedUpdate()
    {
        //if statement is here to avoid null ref. exceptions when player dies.
        if (GameObject.FindGameObjectWithTag("Player") != null)
        {
            //find the players position
            target = GameObject.FindGameObjectWithTag("Player").transform.position;
        }

        if (GameObject.Find("Player").GetComponent<DestroyByContact>().powerPelletActive == false)
        {
            Chase();
        }
        else if (GameObject.Find("Player").GetComponent<DestroyByContact>().powerPelletActive == true)
        {
            RunAway();
        }
    }

    void Chase()
    {
        //use NavMesh to go to that position
        agent.SetDestination(target);
    }

    void RunAway()
    {
        //find some point away from the player and set that as the target.
        agent.SetDestination(oRigin);
    }
}
